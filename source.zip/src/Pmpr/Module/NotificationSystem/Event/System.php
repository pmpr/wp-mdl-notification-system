<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68729e5e5d855             |
    |_______________________________________|
*/
 namespace Pmpr\Module\NotificationSystem\Event; class System extends AbstractEvent { public function wigskegsqequoeks() { $this->waqewsckuayqguos('add_user_notification', [$this, 'mmwauasakomqigqo'], 10, 2); } }
