<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6876b99d64dcb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\NotificationSystem\Event; class System extends AbstractEvent { public function wigskegsqequoeks() { $this->waqewsckuayqguos('add_user_notification', [$this, 'mmwauasakomqigqo'], 10, 2); } }
