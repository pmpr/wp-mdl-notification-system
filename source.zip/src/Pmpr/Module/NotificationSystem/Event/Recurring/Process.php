<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6876b8bf4b3e3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\NotificationSystem\Event\Recurring; use Pmpr\Module\NotificationSystem\Event\AbstractProcess; class Process extends AbstractProcess { const yywkcqkgiskqsyyi = self::csqsymqoqwyowokg . 'recurring_notification_%s'; public function qiiiewaogqowqwaa($yiuogaeewyockeak, $ycooswiwewekokei, $moqewomugocaueis) : int { return $this->ooosmymooksgmyos($yiuogaeewyockeak, $ycooswiwewekokei, sprintf(self::yywkcqkgiskqsyyi, $moqewomugocaueis)); } }
