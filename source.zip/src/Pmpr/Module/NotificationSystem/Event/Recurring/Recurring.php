<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68797250c84c2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\NotificationSystem\Event\Recurring; use Pmpr\Module\NotificationSystem\Event\AbstractEvent; class Recurring extends AbstractEvent { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu('init', [$this, 'init']); } public function init() { } }
