<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6876b99d64dcb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\NotificationSystem\Event; use Pmpr\Common\Foundation\Process\Queue; use Pmpr\Module\NotificationSystem\NotificationSystem; class AbstractProcess extends Queue { const csqsymqoqwyowokg = NotificationSystem::PREFIX . 'job_'; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= NotificationSystem::PREFIX; } }
