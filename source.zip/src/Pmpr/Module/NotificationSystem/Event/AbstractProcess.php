<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68729e5e5d855             |
    |_______________________________________|
*/
 namespace Pmpr\Module\NotificationSystem\Event; use Pmpr\Common\Foundation\Process\Queue; use Pmpr\Module\NotificationSystem\NotificationSystem; class AbstractProcess extends Queue { public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= NotificationSystem::PREFIX; } }
