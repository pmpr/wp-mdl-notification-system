<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68763a4dd0e86             |
    |_______________________________________|
*/
 namespace Pmpr\Module\NotificationSystem; use Pmpr\Common\Foundation\Container\Container as BaseClass; class Container extends BaseClass { }
