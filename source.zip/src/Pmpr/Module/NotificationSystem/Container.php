<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68797250c84c2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\NotificationSystem; use Pmpr\Common\Foundation\Container\Container as BaseClass; class Container extends BaseClass { }
