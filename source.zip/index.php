<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68729e5e5d855             |
    |_______________________________________|
*/
 use Pmpr\Module\NotificationSystem\NotificationSystem; NotificationSystem::symcgieuakksimmu();
