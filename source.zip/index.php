<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68763a4dd0e86             |
    |_______________________________________|
*/
 use Pmpr\Module\NotificationSystem\NotificationSystem; NotificationSystem::symcgieuakksimmu();
