<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             687eace567115             |
    |_______________________________________|
*/
 use Pmpr\Module\NotificationSystem\NotificationSystem; NotificationSystem::symcgieuakksimmu();
