<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68797250c84c2             |
    |_______________________________________|
*/
 use Pmpr\Module\NotificationSystem\NotificationSystem; NotificationSystem::symcgieuakksimmu();
